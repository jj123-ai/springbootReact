import "./App.css";
import GreenPrj from "./components/GreenPrj";
import Prj from "./components/Prj";

function App() {  
  // return <Prj v="사랑합니다." />;
  return <GreenPrj/>;
}

export default App;
